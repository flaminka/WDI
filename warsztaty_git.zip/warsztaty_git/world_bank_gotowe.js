var jsonik =[	{
		"Country Name": "Afganistan",
		"Fertility_rate_2014": "4.843",
		"GDP_PPP_2014": "1942.48461012269",
		"Population_2014": "31627506",
		"Region": "Azja Południowa"
	},
	{
		"Country Name": "Angola",
		"Fertility_rate_2014": "6.08",
		"GDP_PPP_2014": "7327.37949009523",
		"Population_2014": "24227524",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Albania",
		"Fertility_rate_2014": "1.784",
		"GDP_PPP_2014": "11307.5492760222",
		"Population_2014": "2893654",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Zjednoczone Emiraty Arabskie",
		"Fertility_rate_2014": "1.784",
		"GDP_PPP_2014": "67238.9952603094",
		"Population_2014": "9086139",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Argentyna",
		"Fertility_rate_2014": "2.322",
		"GDP_PPP_2014": "19880.7048226267",
		"Population_2014": "42980026",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Armenia",
		"Fertility_rate_2014": "1.531",
		"GDP_PPP_2014": "8117.6085003522",
		"Population_2014": "3006154",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Antigua i Barbuda",
		"Fertility_rate_2014": "2.075",
		"GDP_PPP_2014": "22133.7550197495",
		"Population_2014": "90900",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Australia",
		"Fertility_rate_2014": "1.859",
		"GDP_PPP_2014": "46298.6871835483",
		"Population_2014": "23464086",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Austria",
		"Fertility_rate_2014": "1.44",
		"GDP_PPP_2014": "48658.9800853565",
		"Population_2014": "8541575",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Azerbejdżan",
		"Fertility_rate_2014": "2",
		"GDP_PPP_2014": "17607.6228933646",
		"Population_2014": "9535079",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Burundi",
		"Fertility_rate_2014": "5.948",
		"GDP_PPP_2014": "773.703029354352",
		"Population_2014": "10816860",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Belgium",
		"Fertility_rate_2014": "1.75",
		"GDP_PPP_2014": "44746.8518678043",
		"Population_2014": "11231213",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Benin",
		"Fertility_rate_2014": "4.766",
		"GDP_PPP_2014": "2045.97178728552",
		"Population_2014": "10598482",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Burkina Faso",
		"Fertility_rate_2014": "5.521",
		"GDP_PPP_2014": "1660.46463961144",
		"Population_2014": "17589198",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Bangladesz",
		"Fertility_rate_2014": "2.175",
		"GDP_PPP_2014": "3138.24245715061",
		"Population_2014": "159077513",
		"Region": "Azja Południowa"
	},
	{
		"Country Name": "Bułgaria",
		"Fertility_rate_2014": "1.48",
		"GDP_PPP_2014": "17406.0984643757",
		"Population_2014": "7223938",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Bahrain",
		"Fertility_rate_2014": "2.056",
		"GDP_PPP_2014": "45310.9588503698",
		"Population_2014": "1361930",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Bahamy",
		"Fertility_rate_2014": "1.872",
		"GDP_PPP_2014": "23441.1021553659",
		"Population_2014": "383054",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Bośnia i Hercegowina",
		"Fertility_rate_2014": "1.263",
		"GDP_PPP_2014": "10472.717494029",
		"Population_2014": "3817554",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Białoruś",
		"Fertility_rate_2014": "1.62",
		"GDP_PPP_2014": "18290.7428591897",
		"Population_2014": "9483000",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Belize",
		"Fertility_rate_2014": "2.579",
		"GDP_PPP_2014": "8485.55540299269",
		"Population_2014": "351706",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Boliwia",
		"Fertility_rate_2014": "2.968",
		"GDP_PPP_2014": "6662.80146581681",
		"Population_2014": "10561887",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Brazylia",
		"Fertility_rate_2014": "1.79",
		"GDP_PPP_2014": "15972.0280657904",
		"Population_2014": "206077898",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Barbados",
		"Fertility_rate_2014": "1.794",
		"GDP_PPP_2014": "16136.5647641399",
		"Population_2014": "283380",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Brunei Darussalam",
		"Fertility_rate_2014": "1.874",
		"GDP_PPP_2014": "79059.488901791",
		"Population_2014": "417394",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Bhutan",
		"Fertility_rate_2014": "2.027",
		"GDP_PPP_2014": "7875.8008249096",
		"Population_2014": "765008",
		"Region": "Azja Południowa"
	},
	{
		"Country Name": "Botswana",
		"Fertility_rate_2014": "2.836",
		"GDP_PPP_2014": "16011.8684696706",
		"Population_2014": "2219937",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Republika Środkowoafrykańska",
		"Fertility_rate_2014": "4.286",
		"GDP_PPP_2014": "595.795888331801",
		"Population_2014": "4804316",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Kanada",
		"Fertility_rate_2014": "1.61",
		"GDP_PPP_2014": "44897.2216655232",
		"Population_2014": "35543658",
		"Region": "Ameryka Północna"
	},
	{
		"Country Name": "Szwajcaria",
		"Fertility_rate_2014": "1.52",
		"GDP_PPP_2014": "61282.1098942725",
		"Population_2014": "8188649",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Chile",
		"Fertility_rate_2014": "1.761",
		"GDP_PPP_2014": "22909.7962509559",
		"Population_2014": "17762647",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Chiny",
		"Fertility_rate_2014": "1.562",
		"GDP_PPP_2014": "13439.9076421309",
		"Population_2014": "1364270000",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Wybrzeże Kości Słoniowej",
		"Fertility_rate_2014": "5.001",
		"GDP_PPP_2014": "3262.72656405722",
		"Population_2014": "22157107",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Kamerun",
		"Fertility_rate_2014": "4.704",
		"GDP_PPP_2014": "2986.97418770438",
		"Population_2014": "22773014",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Kongo",
		"Fertility_rate_2014": "6.006",
		"GDP_PPP_2014": "748.982308546287",
		"Population_2014": "74877030",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Kongo",
		"Fertility_rate_2014": "4.869",
		"GDP_PPP_2014": "6307.90169054866",
		"Population_2014": "4504962",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Kolumbia",
		"Fertility_rate_2014": "1.897",
		"GDP_PPP_2014": "13394.0791967416",
		"Population_2014": "47791393",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Komory",
		"Fertility_rate_2014": "4.49",
		"GDP_PPP_2014": "1487.77721583784",
		"Population_2014": "769991",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Republika Zielonego Przyladka",
		"Fertility_rate_2014": "2.303",
		"GDP_PPP_2014": "6475.75966220125",
		"Population_2014": "513906",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Kostaryka",
		"Fertility_rate_2014": "1.819",
		"GDP_PPP_2014": "15028.14728205",
		"Population_2014": "4757606",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Cypr",
		"Fertility_rate_2014": "1.446",
		"GDP_PPP_2014": "30482.6391988363",
		"Population_2014": "1153658",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Czechy",
		"Fertility_rate_2014": "1.46",
		"GDP_PPP_2014": "32386.2453117947",
		"Population_2014": "10525347",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Niemcy",
		"Fertility_rate_2014": "1.39",
		"GDP_PPP_2014": "47099.7180322536",
		"Population_2014": "80982500",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Dżibuti",
		"Fertility_rate_2014": "3.195",
		"GDP_PPP_2014": "3286.64176651131",
		"Population_2014": "876174",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Dania",
		"Fertility_rate_2014": "1.67",
		"GDP_PPP_2014": "47008.8314898187",
		"Population_2014": "5643475",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Dominikana",
		"Fertility_rate_2014": "2.48",
		"GDP_PPP_2014": "13313.8399989038",
		"Population_2014": "10405943",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Algeria",
		"Fertility_rate_2014": "2.857",
		"GDP_PPP_2014": "14277.6284858108",
		"Population_2014": "38934334",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Ekwador",
		"Fertility_rate_2014": "2.542",
		"GDP_PPP_2014": "11506.2044038323",
		"Population_2014": "15902916",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Egipt",
		"Fertility_rate_2014": "3.338",
		"GDP_PPP_2014": "10585.1245571256",
		"Population_2014": "89579670",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Hiszpania",
		"Fertility_rate_2014": "1.27",
		"GDP_PPP_2014": "33822.221543486",
		"Population_2014": "46480882",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Estonia",
		"Fertility_rate_2014": "1.52",
		"GDP_PPP_2014": "28568.4962841273",
		"Population_2014": "1314545",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Etiopia",
		"Fertility_rate_2014": "4.395",
		"GDP_PPP_2014": "1507.20241847384",
		"Population_2014": "96958732",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Finlandia",
		"Fertility_rate_2014": "1.75",
		"GDP_PPP_2014": "41526.2283967305",
		"Population_2014": "5461512",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Fidżi",
		"Fertility_rate_2014": "2.564",
		"GDP_PPP_2014": "8793.96642045047",
		"Population_2014": "886450",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Francja",
		"Fertility_rate_2014": "1.99",
		"GDP_PPP_2014": "40151.8133849079",
		"Population_2014": "66495940",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Mikronezja",
		"Fertility_rate_2014": "3.243",
		"GDP_PPP_2014": "3347.05218909732",
		"Population_2014": "104044",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Gabon",
		"Fertility_rate_2014": "3.909",
		"GDP_PPP_2014": "19526.5549877211",
		"Population_2014": "1687673",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Wielka Brytania",
		"Fertility_rate_2014": "1.83",
		"GDP_PPP_2014": "40745.1870440294",
		"Population_2014": "64613160",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Georgia",
		"Fertility_rate_2014": "1.816",
		"GDP_PPP_2014": "9216.32482918236",
		"Population_2014": "3727000",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Ghana",
		"Fertility_rate_2014": "4.168",
		"GDP_PPP_2014": "4101.92809773675",
		"Population_2014": "26786598",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Gwinea",
		"Fertility_rate_2014": "5.013",
		"GDP_PPP_2014": "1227.34292391477",
		"Population_2014": "12275527",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Gambia",
		"Fertility_rate_2014": "5.717",
		"GDP_PPP_2014": "1638.58817005369",
		"Population_2014": "1928201",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Gwinea-Bissau",
		"Fertility_rate_2014": "4.835",
		"GDP_PPP_2014": "1407.82394494852",
		"Population_2014": "1800513",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Gwinea Równikowa",
		"Fertility_rate_2014": "4.835",
		"GDP_PPP_2014": "45218.0978649919",
		"Population_2014": "820885",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Grecja",
		"Fertility_rate_2014": "1.3",
		"GDP_PPP_2014": "26453.9199032126",
		"Population_2014": "10892413",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Grenada",
		"Fertility_rate_2014": "2.149",
		"GDP_PPP_2014": "12684.1967477716",
		"Population_2014": "106349",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Gwatemala",
		"Fertility_rate_2014": "3.211",
		"GDP_PPP_2014": "7485.84423417129",
		"Population_2014": "16015494",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Gujana",
		"Fertility_rate_2014": "2.558",
		"GDP_PPP_2014": "7254.69542468797",
		"Population_2014": "763893",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Hong Kong",
		"Fertility_rate_2014": "1.234",
		"GDP_PPP_2014": "55463.7403281102",
		"Population_2014": "7241700",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Honduras",
		"Fertility_rate_2014": "2.382",
		"GDP_PPP_2014": "4933.04263008583",
		"Population_2014": "7961680",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Chorwacja",
		"Fertility_rate_2014": "1.46",
		"GDP_PPP_2014": "22002.4800657345",
		"Population_2014": "4238389",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Haiti",
		"Fertility_rate_2014": "3.033",
		"GDP_PPP_2014": "1740.95681427364",
		"Population_2014": "10572029",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Węgry",
		"Fertility_rate_2014": "1.35",
		"GDP_PPP_2014": "25516.8470090461",
		"Population_2014": "9866468",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Indonezja",
		"Fertility_rate_2014": "2.463",
		"GDP_PPP_2014": "10566.952977549",
		"Population_2014": "254454778",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Indie",
		"Fertility_rate_2014": "2.427",
		"GDP_PPP_2014": "5679.58827388634",
		"Population_2014": "1295291543",
		"Region": "Azja Południowa"
	},
	{
		"Country Name": "Irlandia",
		"Fertility_rate_2014": "1.96",
		"GDP_PPP_2014": "51310.9841701548",
		"Population_2014": "4617225",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Iran",
		"Fertility_rate_2014": "1.707",
		"GDP_PPP_2014": "17388.4309424178",
		"Population_2014": "78143644",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Irak",
		"Fertility_rate_2014": "4.566",
		"GDP_PPP_2014": "15266.4709065116",
		"Population_2014": "35273293",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Islandia",
		"Fertility_rate_2014": "1.93",
		"GDP_PPP_2014": "43960.9667496712",
		"Population_2014": "327386",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Izrael",
		"Fertility_rate_2014": "3.08",
		"GDP_PPP_2014": "34956.829130784",
		"Population_2014": "8215700",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Włochy",
		"Fertility_rate_2014": "1.39",
		"GDP_PPP_2014": "36293.8031815337",
		"Population_2014": "60789140",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Jamajka",
		"Fertility_rate_2014": "2.046",
		"GDP_PPP_2014": "8723.17866146945",
		"Population_2014": "2720554",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Jordania",
		"Fertility_rate_2014": "3.422",
		"GDP_PPP_2014": "10788.9230145217",
		"Population_2014": "7416083",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Japonia",
		"Fertility_rate_2014": "1.42",
		"GDP_PPP_2014": "39449.442598389",
		"Population_2014": "127131800",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Kazachstan",
		"Fertility_rate_2014": "2.74",
		"GDP_PPP_2014": "24845.4541371692",
		"Population_2014": "17289224",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Kenia",
		"Fertility_rate_2014": "4.334",
		"GDP_PPP_2014": "2969.02324934242",
		"Population_2014": "44863583",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Kirgistan",
		"Fertility_rate_2014": "3.2",
		"GDP_PPP_2014": "3351.52867057666",
		"Population_2014": "5835500",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Kambodża",
		"Fertility_rate_2014": "2.635",
		"GDP_PPP_2014": "3278.83208465759",
		"Population_2014": "15328136",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Kiribati",
		"Fertility_rate_2014": "3.73",
		"GDP_PPP_2014": "1940.56168422363",
		"Population_2014": "110470",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Korea",
		"Fertility_rate_2014": "1.205",
		"GDP_PPP_2014": "33856.5788281048",
		"Population_2014": "50423955",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Kosowo",
		"Fertility_rate_2014": "2.1",
		"GDP_PPP_2014": "9165.67111960772",
		"Population_2014": "1812771",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Kuwejt",
		"Fertility_rate_2014": "2.105",
		"GDP_PPP_2014": "75197.0292878014",
		"Population_2014": "3753121",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Laos",
		"Fertility_rate_2014": "2.991",
		"GDP_PPP_2014": "5333.52538843413",
		"Population_2014": "6689300",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Lebanon",
		"Fertility_rate_2014": "1.714",
		"GDP_PPP_2014": "14189.7572628034",
		"Population_2014": "5612096",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Liberia",
		"Fertility_rate_2014": "4.719",
		"GDP_PPP_2014": "846.567032923362",
		"Population_2014": "4396554",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "St. Lucia",
		"Fertility_rate_2014": "1.89",
		"GDP_PPP_2014": "10655.1397801514",
		"Population_2014": "183645",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Sri Lanka",
		"Fertility_rate_2014": "2.083",
		"GDP_PPP_2014": "11210.2979913588",
		"Population_2014": "20771000",
		"Region": "Azja Południowa"
	},
	{
		"Country Name": "Lesotho",
		"Fertility_rate_2014": "3.185",
		"GDP_PPP_2014": "2906.98727600647",
		"Population_2014": "2109197",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Litwa",
		"Fertility_rate_2014": "1.59",
		"GDP_PPP_2014": "28067.0834138247",
		"Population_2014": "2932367",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Luksemburg",
		"Fertility_rate_2014": "1.55",
		"GDP_PPP_2014": "99732.4593444194",
		"Population_2014": "556319",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Łotwa",
		"Fertility_rate_2014": "1.52",
		"GDP_PPP_2014": "23884.1291725913",
		"Population_2014": "1993782",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Makau",
		"Fertility_rate_2014": "1.243",
		"GDP_PPP_2014": "140813.517981169",
		"Population_2014": "577914",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Maroko",
		"Fertility_rate_2014": "2.515",
		"GDP_PPP_2014": "7524.04516658113",
		"Population_2014": "33921203",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Mołdawia",
		"Fertility_rate_2014": "1.256",
		"GDP_PPP_2014": "5017.0936356271",
		"Population_2014": "3556397",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Madagaskar",
		"Fertility_rate_2014": "4.409",
		"GDP_PPP_2014": "1446.39024675489",
		"Population_2014": "23571713",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Malediwy",
		"Fertility_rate_2014": "2.123",
		"GDP_PPP_2014": "12534.7096331904",
		"Population_2014": "401000",
		"Region": "Azja Południowa"
	},
	{
		"Country Name": "Meksyk",
		"Fertility_rate_2014": "2.243",
		"GDP_PPP_2014": "17205.5914384142",
		"Population_2014": "125385833",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Macedonia",
		"Fertility_rate_2014": "1.524",
		"GDP_PPP_2014": "13476.983118876",
		"Population_2014": "2075625",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Mali",
		"Fertility_rate_2014": "6.229",
		"GDP_PPP_2014": "1950.58824003987",
		"Population_2014": "17086022",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Malta",
		"Fertility_rate_2014": "1.38",
		"GDP_PPP_2014": "32488.6333670319",
		"Population_2014": "427364",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Birma",
		"Fertility_rate_2014": "2.204",
		"GDP_PPP_2014": "4882.4453294341",
		"Population_2014": "53437159",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Czarnogóra",
		"Fertility_rate_2014": "1.689",
		"GDP_PPP_2014": "15410.0726476579",
		"Population_2014": "621810",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Mongolia",
		"Fertility_rate_2014": "2.655",
		"GDP_PPP_2014": "12012.2369092302",
		"Population_2014": "2909871",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Mozambik",
		"Fertility_rate_2014": "5.359",
		"GDP_PPP_2014": "1137.31678259315",
		"Population_2014": "27216276",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Mauretania",
		"Fertility_rate_2014": "4.603",
		"GDP_PPP_2014": "3890.76188121182",
		"Population_2014": "3969625",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Mauritius",
		"Fertility_rate_2014": "1.43",
		"GDP_PPP_2014": "19230.6575231181",
		"Population_2014": "1260934",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Malawi",
		"Fertility_rate_2014": "5.129",
		"GDP_PPP_2014": "1174.28993701303",
		"Population_2014": "16695253",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Malezja",
		"Fertility_rate_2014": "1.944",
		"GDP_PPP_2014": "25765.7585179412",
		"Population_2014": "29901997",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Namibia",
		"Fertility_rate_2014": "3.522",
		"GDP_PPP_2014": "10010.3984728188",
		"Population_2014": "2402858",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Niger",
		"Fertility_rate_2014": "7.599",
		"GDP_PPP_2014": "949.908768122856",
		"Population_2014": "19113728",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Nigeria",
		"Fertility_rate_2014": "5.65",
		"GDP_PPP_2014": "5940.57014479176",
		"Population_2014": "177475986",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Nikaragua",
		"Fertility_rate_2014": "2.264",
		"GDP_PPP_2014": "4958.80329568206",
		"Population_2014": "6013913",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Holandia",
		"Fertility_rate_2014": "1.68",
		"GDP_PPP_2014": "49055.3831959308",
		"Population_2014": "16865008",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Norwegia",
		"Fertility_rate_2014": "1.78",
		"GDP_PPP_2014": "65713.5104557314",
		"Population_2014": "5137232",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Nepal",
		"Fertility_rate_2014": "2.222",
		"GDP_PPP_2014": "2399.77270368837",
		"Population_2014": "28174724",
		"Region": "Azja Południowa"
	},
	{
		"Country Name": "Nowa Zelandia",
		"Fertility_rate_2014": "1.92",
		"GDP_PPP_2014": "37087.9379929414",
		"Population_2014": "4509700",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Oman",
		"Fertility_rate_2014": "2.774",
		"GDP_PPP_2014": "39678.2993908115",
		"Population_2014": "4236057",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Pakistan",
		"Fertility_rate_2014": "3.617",
		"GDP_PPP_2014": "4833.65539441935",
		"Population_2014": "185044286",
		"Region": "Azja Południowa"
	},
	{
		"Country Name": "Panama",
		"Fertility_rate_2014": "2.444",
		"GDP_PPP_2014": "21130.2017439541",
		"Population_2014": "3867535",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Peru",
		"Fertility_rate_2014": "2.455",
		"GDP_PPP_2014": "12161.9443879789",
		"Population_2014": "30973148",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Filipiny",
		"Fertility_rate_2014": "2.977",
		"GDP_PPP_2014": "7009.80967074326",
		"Population_2014": "99138690",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Papua i Nowa Gwinea",
		"Fertility_rate_2014": "3.757",
		"GDP_PPP_2014": "2868.91634101206",
		"Population_2014": "7463577",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Polska",
		"Fertility_rate_2014": "1.29",
		"GDP_PPP_2014": "25730.20695756",
		"Population_2014": "38011735",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Portugalia",
		"Fertility_rate_2014": "1.21",
		"GDP_PPP_2014": "28892.9317644085",
		"Population_2014": "10401062",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Paragwaj",
		"Fertility_rate_2014": "2.542",
		"GDP_PPP_2014": "8955.58094041456",
		"Population_2014": "6552518",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "West Bank i Gaza",
		"Fertility_rate_2014": "4.176",
		"GDP_PPP_2014": "4550.17320175143",
		"Population_2014": "4294682",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Katar",
		"Fertility_rate_2014": "2.026",
		"GDP_PPP_2014": "139174.278832964",
		"Population_2014": "2172065",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Rumania",
		"Fertility_rate_2014": "1.41",
		"GDP_PPP_2014": "20796.9885641642",
		"Population_2014": "19908979",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Rosja",
		"Fertility_rate_2014": "1.7",
		"GDP_PPP_2014": "25094.7271005568",
		"Population_2014": "143819569",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Ruanda",
		"Fertility_rate_2014": "3.898",
		"GDP_PPP_2014": "1669.50752188405",
		"Population_2014": "11341544",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Arabia Saudyjska",
		"Fertility_rate_2014": "2.765",
		"GDP_PPP_2014": "52268.2955569289",
		"Population_2014": "30886545",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Sudan",
		"Fertility_rate_2014": "4.353",
		"GDP_PPP_2014": "4231.1957285026",
		"Population_2014": "39350274",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Senegal",
		"Fertility_rate_2014": "5.09",
		"GDP_PPP_2014": "2319.1738792865",
		"Population_2014": "14672557",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Singapur",
		"Fertility_rate_2014": "1.25",
		"GDP_PPP_2014": "83798.5892335035",
		"Population_2014": "5469724",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Wyspy Salomona",
		"Fertility_rate_2014": "3.966",
		"GDP_PPP_2014": "2141.01212690556",
		"Population_2014": "572171",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Sierra Leone",
		"Fertility_rate_2014": "4.626",
		"GDP_PPP_2014": "1997.99228104703",
		"Population_2014": "6315627",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Salwador",
		"Fertility_rate_2014": "1.931",
		"GDP_PPP_2014": "8349.20690111386",
		"Population_2014": "6107706",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Serbia",
		"Fertility_rate_2014": "1.43",
		"GDP_PPP_2014": "13806.0330350118",
		"Population_2014": "7130576",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Sudan Południowy",
		"Fertility_rate_2014": "5.022",
		"GDP_PPP_2014": "2028.89535974783",
		"Population_2014": "11911184",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Wyspa Św. Tomasza i Książęca",
		"Fertility_rate_2014": "4.576",
		"GDP_PPP_2014": "3128.40187687322",
		"Population_2014": "186342",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Surinam",
		"Fertility_rate_2014": "2.36",
		"GDP_PPP_2014": "16720.1466320945",
		"Population_2014": "538248",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Słowacja",
		"Fertility_rate_2014": "1.34",
		"GDP_PPP_2014": "29045.7515407083",
		"Population_2014": "5418649",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Słowenia",
		"Fertility_rate_2014": "1.55",
		"GDP_PPP_2014": "31022.1556328654",
		"Population_2014": "2061980",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Szwecja",
		"Fertility_rate_2014": "1.89",
		"GDP_PPP_2014": "46445.7719135224",
		"Population_2014": "9696110",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Suazi",
		"Fertility_rate_2014": "3.266",
		"GDP_PPP_2014": "8517.09175125573",
		"Population_2014": "1269112",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Seszele",
		"Fertility_rate_2014": "2.3",
		"GDP_PPP_2014": "26564.9676381115",
		"Population_2014": "91400",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Czad",
		"Fertility_rate_2014": "6.156",
		"GDP_PPP_2014": "2184.6984737433",
		"Population_2014": "13587053",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Togo",
		"Fertility_rate_2014": "4.584",
		"GDP_PPP_2014": "1407.72551808752",
		"Population_2014": "7115163",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Tajlandia",
		"Fertility_rate_2014": "1.512",
		"GDP_PPP_2014": "15775.6144430824",
		"Population_2014": "67725979",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Tadżikistan",
		"Fertility_rate_2014": "3.49",
		"GDP_PPP_2014": "2704.1068954892",
		"Population_2014": "8295840",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Turkmenistan",
		"Fertility_rate_2014": "2.301",
		"GDP_PPP_2014": "15550.1216828503",
		"Population_2014": "5307188",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Timor Wschodni",
		"Fertility_rate_2014": "5.1",
		"GDP_PPP_2014": "2329.51003652901",
		"Population_2014": "1212107",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Tonga",
		"Fertility_rate_2014": "3.722",
		"GDP_PPP_2014": "5309.42493357575",
		"Population_2014": "105586",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Trinidad i Tobago",
		"Fertility_rate_2014": "1.778",
		"GDP_PPP_2014": "33282.8777138697",
		"Population_2014": "1354483",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Tunezja",
		"Fertility_rate_2014": "2.2",
		"GDP_PPP_2014": "11357.8154267042",
		"Population_2014": "10996600",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Turcja",
		"Fertility_rate_2014": "2.07",
		"GDP_PPP_2014": "19653.6118276374",
		"Population_2014": "77523788",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Tanzania",
		"Fertility_rate_2014": "5.145",
		"GDP_PPP_2014": "2550.4905036351",
		"Population_2014": "51822621",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Uganda",
		"Fertility_rate_2014": "5.775",
		"GDP_PPP_2014": "1799.29374264023",
		"Population_2014": "37782971",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Ukraina",
		"Fertility_rate_2014": "1.498",
		"GDP_PPP_2014": "8683.64084212016",
		"Population_2014": "45362900",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "Urugwaj",
		"Fertility_rate_2014": "2.02",
		"GDP_PPP_2014": "20886.4580379119",
		"Population_2014": "3419516",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "USA",
		"Fertility_rate_2014": "1.8615",
		"GDP_PPP_2014": "54539.6655752119",
		"Population_2014": "318907401",
		"Region": "Ameryka Północna"
	},
	{
		"Country Name": "Uzbekistan",
		"Fertility_rate_2014": "2.2",
		"GDP_PPP_2014": "5673.7861925224",
		"Population_2014": "30757700",
		"Region": "Europa i Azja Środkowa"
	},
	{
		"Country Name": "St. Vincent i Grenadyny",
		"Fertility_rate_2014": "1.974",
		"GDP_PPP_2014": "10857.2875461283",
		"Population_2014": "109360",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Wenezuela",
		"Fertility_rate_2014": "2.365",
		"GDP_PPP_2014": "17664.7393473477",
		"Population_2014": "30693827",
		"Region": "Ameryka Łacińska i Karaiby"
	},
	{
		"Country Name": "Wietnam",
		"Fertility_rate_2014": "1.961",
		"GDP_PPP_2014": "5656.95694019801",
		"Population_2014": "90728900",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Vanuatu",
		"Fertility_rate_2014": "3.347",
		"GDP_PPP_2014": "3046.3922856626",
		"Population_2014": "258883",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Samoa",
		"Fertility_rate_2014": "4.086",
		"GDP_PPP_2014": "5818.90256477879",
		"Population_2014": "191845",
		"Region": "Azja Wschodnia i Pacyfik"
	},
	{
		"Country Name": "Jemen",
		"Fertility_rate_2014": "4.16",
		"GDP_PPP_2014": "3977.43211748823",
		"Population_2014": "26183676",
		"Region": "Środkowy Wschód i Afryka Północna"
	},
	{
		"Country Name": "Republika Południowej Afryki",
		"Fertility_rate_2014": "2.363",
		"GDP_PPP_2014": "13097.973689899",
		"Population_2014": "54058647",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Zambia",
		"Fertility_rate_2014": "5.353",
		"GDP_PPP_2014": "3802.03529241017",
		"Population_2014": "15721343",
		"Region": "Afryka Subsaharyjska"
	},
	{
		"Country Name": "Zimbabwe",
		"Fertility_rate_2014": "3.923",
		"GDP_PPP_2014": "1800.40520920436",
		"Population_2014": "15245855",
		"Region": "Afryka Subsaharyjska"
	}
];